# Mounika Thudi
# Z1948596
# Assignment 5

#################################################
#####     1a. Data Utilities (15 pts)
#################################################


import os
import json
from urllib.request import urlretrieve
fname = os.path.join(os.path.dirname(__file__),'food-data-sample.json')
sentinel = 1
data = []


#download_data method
def download_data():
    url = "http://faculty.cs.niu.edu/~dakoop/cs503-2022sp/a3/food-data-sample.json"
    local_fname = 'food-data-sample.json'
    if not os.path.exists(fname):
        print('downloading')
        urlretrieve(url, fname)
    return fname


#get_data method
def get_data():
    download_data()
    global sentinel
    global data
    if len(data)==0 or  sentinel == 1:
        #Read the data only if not read
        print('data loaded')
        data = json.load(open(fname))
        sentinel = 0 
        return data
    else:
        return data


#parse_ingredients method
def parse_ingredients(value):
    ingredients_list = []
    for dict in data:
        if dict['fdc_id'] == value :
            if dict['ingredients'] is not None:
                ingredients = dict['ingredients']
                ingredients1_list = ingredients.split(',')
                ingredients_list.extend(ingredients1_list)             
    return ingredients_list
        
    





