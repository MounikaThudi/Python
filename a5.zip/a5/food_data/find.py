# Mounika Thudi
# Z1948596
# Assignment 5

#################################################
### 1b. Finding items (15 pts)
#################################################

from . import util
from collections import defaultdict
import re
import sys

# get_by_brand method
def get_by_brand(brand):
    brand_owner_match_list = []
    data = util.get_data()
    for dict in data:
        if dict['brand_owner'] is not None:
            if dict['brand_owner'].lower().strip() == brand.lower().strip():
                brand_owner_match_list.append(dict)
    return brand_owner_match_list

#get_by_description method
def get_by_description(description):
    description_match_list = []
    data = util.get_data()
    description = description.replace('*', '.*')
    reg = re.compile(description, re.IGNORECASE)
    for dict in data:
        if dict['description'] is not None:
            description_string = dict['description']
            if reg.search(description_string.lower()):
                description_match_list.append(dict)
    return description_match_list

#3. [CSCI 503 Only] Add Category Filtering (15 pts)
def filter_by_category(data, category):
    return [d for d in data if d["branded_food_category"] == category]


#################################################
### 2. Command-Line Programs
### 2a. food_data.find (15 pts)  
### 3. [CSCI 503 Only] Add Category Filtering (15 pts)
#################################################


if __name__ == '__main__':
    

    #def load_data():
        #download_data()
        #get_data()

    #print(len(sys.argv))
    
    #print(sys.argv[1])
    # print(sys.argv[2])
    # print(sys.argv[3])
    # print(sys.argv[4])
    # print(sys.argv[0])
    usage_string = "Usage: python -m food_data.find -b <brand> | -d <description>"
    if len(sys.argv) == 3:
        if sys.argv[1] == '-b':
            util.get_data()
            brand_name = sys.argv[2]
            #brand_name = brand_name[1:-1]
            dicts = get_by_brand(brand_name)
            print(dicts)

        elif sys.argv[1] == '-d':
            util.get_data()
            description = sys.argv[2]
            description = description[1:-1]
            dicts = get_by_description(description)
            for d in dicts:
                print(d["fdc_id"], d["brand_owner"], d["description"])

    elif len(sys.argv) == 5:
        if sys.argv[1] == '-c':
            category = sys.argv[2]
            #category = category[1:-1]
            if sys.argv[3] == '-b':
                util.get_data()
                brand_name = sys.argv[4]
                #brand_name = brand_name[1:-1]
                dicts = get_by_brand(brand_name)
                dicts = filter_by_category(dicts, category)
                for d in dicts:
                    print(d["fdc_id"], d["brand_owner"], d["description"])

            elif sys.argv[3] == '-d':
                util.get_data()
                description = sys.argv[4]
                description = description[1:-1]
                dicts = get_by_description(description)
                dicts = filter_by_category(dicts, category)

                for d in dicts:
                    print(d["fdc_id"], d["brand_owner"], d["description"])

            else:
                print(usage_string)

        elif sys.argv[3] == '-c':
            category = sys.argv[4]
            #category = category[1:-1]

            if sys.argv[1] == '-b':
                util.get_data()
                brand_name = sys.argv[2]
                #brand_name = brand_name[1:-1]
                dicts = get_by_brand(brand_name)
                dicts = filter_by_category(dicts, category)
                for d in dicts:
                    print(d["fdc_id"], d["brand_owner"], d["description"])

            elif sys.argv[1] == '-d':
                util.get_data()
                description = sys.argv[2]
                #description = description[1:-1]
                dicts = get_by_description(description)
                dicts = filter_by_category(dicts, category)

                for d in dicts:
                    print(d["fdc_id"], d["brand_owner"], d["description"])

            else:
                print(usage_string)

    else:
        print(usage_string)
