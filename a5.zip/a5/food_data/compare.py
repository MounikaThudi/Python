# Mounika Thudi
# Z1948596
# Assignment 5

#################################################
### 1c. Comparison (15 pts)
#################################################

from matplotlib.pyplot import flag
from .util import *
from .find import *
from collections import defaultdict

data = get_data()

#diff_nutrition  function
def diff_nutrition(value1, value2, flag=False):
    list1 = []
    list2 = []
    difference_list = []
    for dict in data:
        if dict['fdc_id'] == value1:
            list1.extend(
                [('Serving Size', dict['serving_size'], dict['serving_size_unit'])])
            listnutrition1 = (dict['nutrition'])
            serving_size1 = dict['serving_size']
            for i in listnutrition1:
                list1.extend([(i['name'], i['amount'], i['unit_name'])])
        if dict['fdc_id'] == value2:
            serving_size2 = dict['serving_size']
            n = serving_size1/serving_size2  #scaling factor for extra credit question

            list2.extend(
                [('Serving Size', dict['serving_size'] * n, dict['serving_size_unit'])])
            listnutrition2 = (dict['nutrition'])

            if flag:                        #check for flag before scaling
                for i in listnutrition2:
                    list2.extend(
                        [(i['name'], round(i['amount'] * n, 2), i['unit_name'])])
            else:
                for i in listnutrition2:
                    list2.extend(
                        [(i['name'], round(i['amount'], 2), i['unit_name'])])

    for i in list1:
        for j in list2:
            if i[0] == j[0]:
                difference = i[1]-j[1]
                difference_list.extend([(i[0], difference, i[2])])
    return difference_list

#diff_ingredients  function
def diff_ingredients(fdc_value1, fdc_value2):
    ingredient1 = parse_ingredients(fdc_value1)
    ingredient2 = parse_ingredients(fdc_value2)
    ingredient1_set = set(ingredient1)
    ingredient2_set = set(ingredient2)
    set1 = set()
    set2 = set()
    set3 = set()
    set1 = ingredient1_set & ingredient2_set
    set2 = ingredient1_set - ingredient2_set
    set3 = ingredient2_set - ingredient1_set
    return (set1, set2, set3)


#################################################
### 2. Command-Line Programs
### 2b. food_data.compare (15 pts)
### EXTRA CREDIT INCLUDED
#################################################

if __name__ == '__main__':

    #def load_data():
        #download_data()
        #get_data()

    import sys
    usage_string = """python -m food_data.compare -n | -i fdc_id1 fdc_id2\npython -m food_data.compare -n -f fdc_id1 fdc_id2"""
    if len(sys.argv) == 4:
        valid_id = False
        try:
            id1, id2 = int(sys.argv[2]), int(sys.argv[3])
            valid_id = True
        except ValueError:
            print(usage_string)

        if valid_id:
            if sys.argv[1] == '-n':
                util.get_data()
                diff = diff_nutrition(id1, id2)
                for d in diff:
                    val = d[1]
                    sym = ''
                    if val >= 0:
                        sym = '+'
                    print(f"{d[0]}: {sym}{round(val,2)} {d[2]}")

            elif sys.argv[1] == '-i':
                util.get_data()
                set1, set2, set3 = diff_ingredients(id1, id2)
                for s in set1:
                    print(" ", s.strip())
                for s in set2:
                    print("-", s.strip())
                for s in set3:
                    print("+", s.strip())

            else:
                print(usage_string)

    elif len(sys.argv) == 5:
        if sys.argv[2] == '-f':
            valid_id = False
            try:
                id1, id2 = int(sys.argv[3]), int(sys.argv[4])
                valid_id = True
            except ValueError:
                print(usage_string)

            if valid_id:
                if sys.argv[1] == '-n':
                    util.get_data()
                    diff = diff_nutrition(id1, id2, flag=True)
                    for d in diff:
                        val = d[1]
                        sym = ''
                        if val >= 0:
                            sym = '+'
                        print(f"{d[0]}: {sym}{round(val,2)} {d[2]}")

                elif sys.argv[1] == '-i':
                    util.get_data()
                    set1, set2, set3 = diff_ingredients(id1, id2)
                    for s in set1:
                        print(" ", s.strip())
                    for s in set2:
                        print("-", s.strip())
                    for s in set3:
                        print("+", s.strip())

                else:
                    print(usage_string)

            else:
                print(usage_string)

    else:
        print(usage_string)
